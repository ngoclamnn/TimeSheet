﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeSheet.Model
{
    public class TimeSheetDto
    {
        public string osdTimesheetId { get; set; }
        public DateTime osdTimeOut { get; set; }
        public string TotalHour
        {
            get
            {
                var ts = TimeSpan.FromHours(osdHoursPerDay);
                return ts.Hours + ":" + ts.Minutes;
            }
        }
        public DateTime osdTimeIn { get; set; }
        public double Missing
        {
            get
            {
                return (osdHoursPerDay - 8)*60;
            }
        }
        public string osdFullNameEN { get; set; }
        public string osdFullNameVN { get; set; }
        public double osdHoursPerDay { get; set; }
        public double osdHoursPerDayUntilNow { get; set; }
        public double osdFullHoursPerday { get; set; }
        public DateTime osdWorkingDate { get; set; }
        public string LastName { get; set; }
        public string MidName { get; set; }
        public string FirstName { get; set; }
        public int LimitedTime { get; set; }

        public DateTime Expected { get
            {
                return osdTimeIn.AddHours(9.5).AddHours(-Missing/60);
            } }
    }
}
